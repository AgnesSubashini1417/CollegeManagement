
<?php
session_start();

// Allow requests from your React frontend
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Get JSON input
$data = json_decode(file_get_contents("php://input"), true);
if (!isset($data['regno'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Student registration number is required']);
    exit();
}

$regno = $data['regno'];

// Update student approval status
$sql = "UPDATE userlogin SET approved = 1 WHERE regno = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $regno);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Student approved successfully']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to approve student']);
}

$stmt->close();
$conn->close();
?>
