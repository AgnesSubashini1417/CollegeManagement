<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Handle pre-flight (OPTIONS) request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "college";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection error
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Fetch total approved certificates (where approved = 1)
$resultApprovedCertificates = $conn->query("SELECT COUNT(*) AS count FROM userlogin WHERE approved = 1");
$totalApprovedCertificates = ($resultApprovedCertificates) ? $resultApprovedCertificates->fetch_assoc()['count'] : 0;

// Fetch total students count
$resultStudents = $conn->query("SELECT COUNT(*) AS count FROM userlogin");
$totalStudents = ($resultStudents) ? $resultStudents->fetch_assoc()['count'] : 0;

// Return JSON response
echo json_encode([
    'success' => true,
    'approvedCertificates' => $totalApprovedCertificates,
    'totalStudents' => $totalStudents
]);

// Close database connection
$conn->close();
?>
