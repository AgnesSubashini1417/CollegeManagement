import React from 'react'
import Home from './Components/Home'
import Admin from './Components/Admin';
import User from './Components/User';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './Components/Admindashboard';
import Courses from './Components/Courses';
import Userregister from './Components/Userregister';
import Userdashboard from './Components/Userdashboard';
import Userprofile from './Components/userprofile';
import CourseDetails from './Components/Coursedetails';
import DegreeCertificate from './Components/Degreecertificate';



function App() {
  return (
    <Router>
      <Routes>
        <Route path="/"  element={<Home/>}/>
        <Route path='/admin'  element={<Admin/>}/>
        <Route path='/user'  element={<User/>}/>
        <Route path='/dashboard' element={<Header/>}/>
        <Route path='/course' element={<Courses/>}/>
        <Route path='/userregister' element={<Userregister/>}/>
        <Route path='/userdashboard' element={<Userdashboard/>}/>
        <Route path='/profile'  element={<Userprofile/>}/>
        <Route path="/:course"  element={<CourseDetails/>}/>
        <Route path="/certificate" element={<DegreeCertificate/>}/>
        



      </Routes>
    </Router>
  )
}

export default App
// import React, { useState, useEffect } from 'react';
// import DegreeCertificate from './Components/Degreecertificate';

// const App = () => {
//   const [student, setStudent] = useState(null);

//   useEffect(() => {
//     // Simulate fetching student data from an API or other source
//     setTimeout(() => {
//       // Replace this with your actual student data
//       setStudent({
//         name: 'John Doe',
//         regNo: '12345678',
//         course: 'Bachelor of Computer Applications (BCA)',
//         grade: 'A',
//         year: '2025',
//       });
//     }, 2000); // Simulate a delay in fetching data
//   }, []);

//   return (
//     <div>
//       {student ? <DegreeCertificate student={student} /> : <div>Loading student data...</div>}
//     </div>
//   );
// };

// export default App;

