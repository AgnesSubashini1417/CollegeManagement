import React from 'react';
import { Navbar, Nav, Container, Row, Col, Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Userdashboard.css';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';

const Userdashboard = () => {
  return (
    <>
      {/* Navbar */}
      <header>
        <Navbar
          collapseOnSelect
          expand="lg"
          bg="dark"
          variant="dark"
          fixed="top"
          className="header-back w-100"
        >
          <div className="container-fluid">
            <Navbar.Brand href="../index.php" className="d-flex align-items-center">
              {/* <h3 className="text-light text-uppercase ml-2">Admin Dashboard</h3> */}
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-end">
              <Nav>
                <Nav.Link href="/profile" className="nav-item active">
                  Certificate
                </Nav.Link>
                {/* <Nav.Link href="../academics.php" className="nav-item active">
                  Certificate
                </Nav.Link>
                <Nav.Link href="../admission.php" className="nav-item active">
                  History
                </Nav.Link> */}
                <Nav.Link href="/" className="nav-item active">
                  <FontAwesomeIcon icon={faSignOutAlt} className="text-white fa-lg" />
                </Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </div>
        </Navbar>
      </header>

      {/* Welcome Box */}
      <div className="welcome-section">
        <Container className="text-center mt-5 pt-5">
          <Row>
            <Col>
              <Card className="welcome-card">
                <Card.Body>
                  <h2 className="welcome-title">Welcome to College Management</h2>
                  {/* <p className="welcome-message">Manage your courses, certificates, and students easily.</p> */}
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
};

export default Userdashboard;
