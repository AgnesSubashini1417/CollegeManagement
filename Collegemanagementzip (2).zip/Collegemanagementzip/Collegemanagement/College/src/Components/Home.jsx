import React from "react";
import { useNavigate } from "react-router-dom";
import './Home.css';


const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="login-container">
      <div className="page-title">
        College Management System
        <hr />
      </div>
      <div className="button-group">
        <button className="nav-button" onClick={() => navigate("/admin")}>
          Admin
        </button>
        <button className="nav-button" onClick={() => navigate("/user")}>
          User
        </button>
      </div>
    </div>
  );
};

export default Home;
