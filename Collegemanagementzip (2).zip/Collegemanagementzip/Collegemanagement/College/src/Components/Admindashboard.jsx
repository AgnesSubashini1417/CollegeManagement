import React, { useEffect, useState } from 'react';
import { Navbar, Nav, Container, Row, Col, Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';

const AdminDashboard = () => {
  const [totalCourses, setTotalCourses] = useState(0);
  const [totalStudents, setTotalStudents] = useState(0);
  const [approvedCertificates, setApprovedCertificates] = useState(0); // ✅ Corrected Variable Name

  useEffect(() => {
    fetch('http://localhost/collegemanagementreact/controllers/api/user/count.php')
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        if (data.success) {
          setTotalCourses(data.totalCourses);
          setTotalStudents(data.totalStudents);
          setApprovedCertificates(data.approvedCertificates); // ✅ Corrected Variable Name
        } else {
          console.error("Error fetching data:", data.message);
        }
      })
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  return (
    <>
      {/* Navbar */}
      <Navbar expand="lg" bg="dark" variant="dark" fixed="top">
        <Container>
          <Navbar.Brand>Admin Dashboard</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse className="justify-content-end">
            <Nav>
              <Nav.Link href="/course">CourseCertificate</Nav.Link>
              {/* <Nav.Link href="/history">History</Nav.Link> */}
              <Nav.Link href="/">
                <FontAwesomeIcon icon={faSignOutAlt} className="text-white" />
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Dashboard Stats Section */}
      <Container className="stats-section">
        <Row className="justify-content-center">
          <Col md={5} className="mb-4">
            <Card className="stats-card">
              <Card.Body>
                <h5 className="card-title">Total Courses</h5>
                <p className="card-text">5</p>
              </Card.Body>
            </Card>
          </Col>
          <Col md={5} className="mb-4">
            <Card className="stats-card">
              <Card.Body>
                <h5 className="card-title">Total Students</h5>
                <p className="card-text">{totalStudents}</p>
              </Card.Body>
            </Card>
          </Col>
          <Col md={5} className="mb-4">
            <Card className="stats-card">
              <Card.Body>
                <h5 className="card-title">Approved Certificates</h5>
                <p className="card-text">{approvedCertificates}</p> {/* ✅ Corrected Variable */}
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default AdminDashboard;
