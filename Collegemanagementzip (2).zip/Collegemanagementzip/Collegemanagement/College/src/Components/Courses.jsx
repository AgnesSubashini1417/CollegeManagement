import React from 'react';
import { Navbar, Nav, Container, Row, Col, Card, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Courses.css';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom'; // Ensure you're using react-router-dom for navigation

const Courses = () => {
  return (
    <>
      {/* Navbar */}
      <header>
        <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark" fixed="top" className="header-back w-100">
          <div className="container-fluid">
            <Navbar.Brand href="../index.php" className="d-flex align-items-center">
              <h3 className="text-light text-uppercase ml-2">Admin Dashboard</h3>
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-end">
              <Nav>
                <Nav.Link as={Link} to="/course" className="nav-item active">
                  Certificate
                </Nav.Link>
                
                {/* <Nav.Link href="../admission.php" className="nav-item active">
                  History
                </Nav.Link> */}
                <Nav.Link href="/" className="nav-item active">
                  <FontAwesomeIcon icon={faSignOutAlt} className="text-white fa-lg" />
                </Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </div>
        </Navbar>
      </header>

      {/* Glassmorphism Box for Courses */}
      <div className="courses-container">
        <Container className="text-center mt-5 pt-5">
          <h3 className="text-light mb-5 ">List of Courses</h3>
          <Row>
            <Col md={4}>
              <Card className="glass-card">
                <Card.Body>
                  <h5 className="card-title">BCA</h5>
                  <Link to="/bca" className="btn btn-primary">View details</Link>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="glass-card">
                <Card.Body>
                  <h5 className="card-title">BSc</h5>
                  <Link to="/bsc" className="btn btn-primary">View details</Link>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="glass-card">
                <Card.Body>
                  <h5 className="card-title">MBA</h5>
                  <Link to="/mba" className="btn btn-primary">View details</Link>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="glass-card">
                <Card.Body>
                  <h5 className="card-title">BE</h5>
                  <Link to="/be" className="btn btn-primary">View details</Link>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="glass-card">
                <Card.Body>
                  <h5 className="card-title">MCA</h5>
                  <Link to="/mca" className="btn btn-primary">View details</Link>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
};

export default Courses;
