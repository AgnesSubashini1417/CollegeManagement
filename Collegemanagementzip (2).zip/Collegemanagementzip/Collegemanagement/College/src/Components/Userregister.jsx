import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Userregister.css'; // Link your CSS file here

function Userregister() {
  const [formData, setFormData] = useState({
    studentName: '',
    regNo: '',
    email: '',
    course: '',
    grade: '',
    year: '',
  });
  const navigate = useNavigate(); 

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      // Send a POST request with form data as JSON
      const response = await axios.post('http://localhost/collegemanagementreact/controllers/api/user/register.php', formData, {
        headers: {
          'Content-Type': 'application/json', // Specify that you're sending JSON
        },
      });

      // Handle the response
      if (response.data.success) {
        alert('Registration Successful!');
        navigate('/user')
      } else {
        alert('Error: ' + response.data.message);
      }
    } catch (error) {
      console.error('There was an error submitting the form!', error);
      alert('Error: Could not submit the form.');
    }
  };

  return (
    <div className="register-container">
      <div className="register-card">
        <h2>Register for Courses</h2>
        <form onSubmit={handleSubmit} className="register-form">
          <div className="input-group">
            <label htmlFor="studentName">Student Name:</label>
            <input
              type="text"
              id="studentName"
              name="studentName"
              value={formData.studentName}
              onChange={handleChange}
              placeholder="Enter full name"
              required
            />
          </div>

          <div className="input-group">
            <label htmlFor="regNo">Registration Number:</label>
            <input
              type="text"
              id="regNo"
              name="regNo"
              value={formData.regNo}
              onChange={handleChange}
              placeholder="Enter registration number"
              required
            />
          </div>

          <div className="input-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter email"
              required
            />
          </div>

          <div className="input-group">
            <label htmlFor="course">Course:</label>
            <input
              type="text"
              id="course"
              name="course"
              value={formData.course}
              onChange={handleChange}
              placeholder="Enter course name"
              required
            />
          </div>

          <div className="input-group">
            <label htmlFor="grade">Grade:</label>
            <input
              type="text"
              id="grade"
              name="grade"
              value={formData.grade}
              onChange={handleChange}
              placeholder="Enter grade"
              required
            />
          </div>

          <div className="input-group">
            <label htmlFor="year">Year:</label>
            <input
              type="text"
              id="year"
              name="year"
              value={formData.year}
              onChange={handleChange}
              placeholder="Enter year of study"
              required
            />
          </div>

          <button type="submit" className="submit-btn">Register</button>
        </form>
      </div>
    </div>
  );
}

export default Userregister;
