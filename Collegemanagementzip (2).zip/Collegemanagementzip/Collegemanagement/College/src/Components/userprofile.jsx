// import React, { useState, useEffect } from "react";
// import axios from "axios";
// import { Navbar, Nav, Container, Button } from "react-bootstrap";
// import "bootstrap/dist/css/bootstrap.min.css";
// import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// import { faSignOutAlt } from "@fortawesome/free-solid-svg-icons";
// import "./userprofile.css";

// function UserProfile() {
//   const [student, setStudent] = useState(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     axios
//       .get("http://localhost/collegemanagementreact/controllers/api/user/userprofile.php", {
//         withCredentials: true,
//       })
//       .then((response) => {
//         if (response.data.success) {
//           setStudent(response.data.student);
//         } else {
//           console.error("Failed to fetch student data:", response.data.message);
//         }
//         setLoading(false);
//       })
//       .catch((error) => {
//         console.error("Error fetching student data:", error);
//         setLoading(false);
//       });
//   }, []);

//   return (
//     <>
//       <header>
//         <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark" fixed="top">
//           <Container>
//             <Navbar.Brand href="#" className="d-flex align-items-center">
//               <h3 className="text-light text-uppercase ml-2">User Profile</h3>
//             </Navbar.Brand>
//             <Navbar.Toggle aria-controls="responsive-navbar-nav" />
//             <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-end">
//               <Nav>
//                 <Nav.Link href="/userdashboard">Profile</Nav.Link>
//                 <Nav.Link href="/certificate">Certificate</Nav.Link>
//                 <Nav.Link href="/history">History</Nav.Link>
//                 <Nav.Link href="/logout">
//                   <FontAwesomeIcon icon={faSignOutAlt} className="text-white fa-lg" />
//                 </Nav.Link>
//               </Nav>
//             </Navbar.Collapse>
//           </Container>
//         </Navbar>
//       </header>

//       <div className="user-profile text-center mt-5 pt-5">
//         <h2>Student Profile</h2>
//         <Container>
//           {loading ? (
//             <p>Loading student data...</p>
//           ) : student ? (
//             <table className="profile-table">
//               <thead>
//                 <tr>
//                   <th>Student Name</th>
//                   <th>Reg No</th>
//                   <th>Email</th>
//                   <th>Course</th>
//                   <th>Grade</th>
//                   <th>Year</th>
//                   <th>Actions</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 <tr>
//                   <td>{student.studentname}</td>
//                   <td>{student.regno}</td>
//                   <td>{student.email}</td>
//                   <td>{student.course}</td>
//                   <td>{student.grade}</td>
//                   <td>{student.year}</td>
//                   <td>
//                     <Button variant="primary" disabled={!student.approved}>
//                       {student.approved ? "Get Certificate" : "Request"}
//                     </Button>
//                   </td>
//                 </tr>
//               </tbody>
//             </table>
//           ) : (
//             <p>No student data found.</p>
//           )}
//         </Container>
//       </div>
//     </>
//   );
// }

// export default UserProfile;
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { Navbar, Nav, Container, Button } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSignOutAlt } from "@fortawesome/free-solid-svg-icons";
import "bootstrap/dist/css/bootstrap.min.css";
import "./userprofile.css";

function UserProfile() {
  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost/collegemanagementreact/controllers/api/user/userprofile.php", {
        withCredentials: true,
      })
      .then((response) => {
        if (response.data.success) {
          setStudent(response.data.student);
        } else {
          console.error("Failed to fetch student data:", response.data.message);
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching student data:", error);
        setLoading(false);
      });
  }, []);

  const handleCertificateClick = () => {
    if (student?.approved) {
      navigate("/certificate", { state: { student } });
    } else {
      alert("Your request for a certificate is pending approval.");
    }
  };

  return (
    <>
      <header>
        <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark" fixed="top">
          <Container>
            <Navbar.Brand href="#">User Profile</Navbar.Brand>
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-end">
              <Nav>
                <Nav.Link href="/userdashboard">Certificate</Nav.Link>
                {/* <Nav.Link href="/certificate">Certificate</Nav.Link>
                <Nav.Link href="/history">History</Nav.Link> */}
                <Nav.Link href="/">
                  <FontAwesomeIcon icon={faSignOutAlt} className="text-white fa-lg" />
                </Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </header>

      <div className="user-profile text-center mt-5 pt-5">
        <h2>Student Profile</h2>
        <Container>
          {loading ? (
            <p>Loading student data...</p>
          ) : student ? (
            <table className="profile-table">
              <thead>
                <tr>
                  <th>Student Name</th>
                  <th>Reg No</th>
                  <th>Email</th>
                  <th>Course</th>
                  <th>Grade</th>
                  <th>Year</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{student.studentname}</td>
                  <td>{student.regno}</td>
                  <td>{student.email}</td>
                  <td>{student.course}</td>
                  <td>{student.grade}</td>
                  <td>{student.year}</td>
                  <td>
                    <Button variant="primary" onClick={handleCertificateClick}>
                      {student.approved ? "Get Certificate" : "Request"}
                    </Button>
                  </td>
                </tr>
              </tbody>
            </table>
          ) : (
            <p>No student data found.</p>
          )}
        </Container>
      </div>
    </>
  );
}

export default UserProfile;
