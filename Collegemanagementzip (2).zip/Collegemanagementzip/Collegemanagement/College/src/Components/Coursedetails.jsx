import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, Link } from "react-router-dom";
import { Navbar, Nav, Container, Table, Button } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSignOutAlt } from "@fortawesome/free-solid-svg-icons";

const CourseDetails = () => {
  const { course } = useParams();
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get(
        `http://localhost/collegemanagementreact/controllers/api/admin/course.php?course=${course}`,
        { withCredentials: true }
      )
      .then((response) => {
        if (response.data.success) {
          setStudents(response.data.students);
        } else {
          alert("No students found for this course");
        }
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching students:", error);
        setLoading(false);
      });
  }, [course]);

  const handleApproval = (regno) => {
    axios
      .post(
        "http://localhost/collegemanagementreact/controllers/api/admin/approve.php",
        { regno },
        { withCredentials: true }
      )
      .then((response) => {
        if (response.data.success) {
          setStudents((prevStudents) =>
            prevStudents.map((student) =>
              student.regno === regno ? { ...student, approved: 1 } : student
            )
          );
        } else {
          alert("Approval failed");
        }
      })
      .catch((error) => console.error("Error approving student:", error));
  };

  return (
    <>
      {/* Navbar */}
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark" fixed="top">
        <Container>
          <Navbar.Brand as={Link} to="/">Admin Dashboard</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-end">
            <Nav>
              <Nav.Link as={Link} to="/course">Courses</Nav.Link>
              <Nav.Link as={Link} to="/">
                <FontAwesomeIcon icon={faSignOutAlt} className="text-white" />
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Course Details Section */}
      <Container className="mt-5 pt-5">
        <h3 className="text-center mb-4">List of {course} Students</h3>
        {loading ? (
          <p className="text-center">Loading...</p>
        ) : (
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Student Name</th>
                <th>Reg No</th>
                <th>Email</th>
                <th>Course</th>
                <th>Grade</th>
                <th>Year</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {students.map((student) => (
                <tr key={student.regno}>
                  <td>{student.studentname}</td>
                  <td>{student.regno}</td>
                  <td>{student.email}</td>
                  <td>{student.course}</td>
                  <td>{student.grade}</td>
                  <td>{student.year}</td>
                  <td>
                    <Button
                      onClick={() => handleApproval(student.regno)}
                      variant={student.approved ? "secondary" : "success"}
                      disabled={student.approved}
                    >
                      {student.approved ? "Send" : "Approve"}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
        <div className="text-center mt-3">
          <Link to="/course">
            <Button variant="primary">Back to Courses</Button>
          </Link>
        </div>
      </Container>
    </>
  );
};

export default CourseDetails;
