import React, { useRef } from "react";
import { useLocation } from "react-router-dom";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import "./Degreecertificate.css";
import logo from "../assets/images/LOGO.jpg";
import seal from "../assets/images/seal.webp";
import signature from "../assets/images/signature.png";

const DegreeCertificate = () => {
  const location = useLocation();
  const student = location.state?.student;
  const certificateRef = useRef();

  // Get the current date
  const currentDate = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const downloadPDF = () => {
    window.scrollTo(0, 0); // Ensure all content is visible before capture
    const input = certificateRef.current;

    html2canvas(input, { scale: 2, useCORS: true }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${student.studentname}_Degree_Certificate.pdf`);
    });
  };

  if (!student) {
    return <div>Loading certificate...</div>;
  }

  return (
    <div className="certificate-wrapper">
      <div className="certificate-container">
        <div className="certificate" ref={certificateRef}>
          {/* Header with Logo */}
          <div className="header">
            <img src={logo} alt="University Logo" className="logo" />
            <h1 className="university-name">XYZ University</h1>
            <p className="university-motto">"Empowering Knowledge"</p>
          </div>

          {/* Title */}
          <div className="title">
            <h2>Degree Certificate</h2>
            <p className="subtitle">This is to certify that</p>
          </div>

          {/* Student Information */}
          <div className="student-info">
            <p><strong>Student Name:</strong> {student.studentname}</p>
            <p><strong>Reg No:</strong> {student.regno}</p>
            <p><strong>Course:</strong> {student.course}</p>
            <p><strong>Grade:</strong> {student.grade}</p>
            <p><strong>Year:</strong> {student.year}</p>
          </div>

          {/* Certificate Body */}
          <div className="certificate-body">
            <p>
              This certifies that the above-named student has successfully completed all required courses and fulfilled the necessary academic requirements for the award of the degree.
            </p>
          </div>

          {/* Footer with Signature and Seal */}
          <div className="footer">
            <div className="signature">
              <img src={signature} alt="Signature" className="signature-image" />
              <p className="signature-line">Signature of Principal</p>
              <p className="signature-line">Signature of Dean</p>
            </div>
            <div className="seal">
              <img src={seal} alt="University Seal" className="seal-image" />
              <p><strong>Issued on:</strong> {currentDate}</p>  {/* Dynamic Current Date */}
            </div>
          </div>
        </div>
      </div>

      {/* Download Button - Always Visible */}
      <button className="download-btn" onClick={downloadPDF}>Download PDF</button>
    </div>
  );
};

export default DegreeCertificate;
