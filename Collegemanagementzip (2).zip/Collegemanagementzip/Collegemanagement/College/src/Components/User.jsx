import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './User.css';

const User = () => {
  const [email, setEmail] = useState('');
  const [regno, setRegNo] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Sending email and regNo to the backend API for authentication
      const response = await axios.post('http://localhost/collegemanagementreact/controllers/api/user/userlogin.php', {
        email,
        regno,
      }, {
        withCredentials: true // Ensure that cookies (session) are sent
      });

      if (response.data.success) {
        // If login is successful, redirect to dashboard
        navigate('/userdashboard');
      } else {
        alert('Invalid email or registration number!');
      }
    } catch (error) {
      console.error('There was an error with the login request!', error);
      alert('Error: Could not login.');
    }
  };

  return (
    <div className="login-container">
      <div className="glass-card">
        <h1 className="page-title">User Login</h1>
        <form onSubmit={handleSubmit} className="login-form">
          <div className="input-container">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
            />
          </div>
          <div className="input-container">
            <label htmlFor="regNo">Registration Number:</label>
            <input
              type="text"
              id="regNo"
              value={regno}
              onChange={(e) => setRegNo(e.target.value)}
              placeholder="Enter your registration number"
              required
            />
          </div>
          <button type="submit" className="submit-button">Login</button>
        </form>
        <p className="register-text">Don't have an account? <a href="/userregister">Register</a></p>
      </div>
    </div>
  );
};

export default User;
